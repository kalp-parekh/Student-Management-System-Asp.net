﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

public partial class admission : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         try
        {
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = "SERVER=localhost;DATABASE=studentmanagementdb;UID=root;password=;";
            con.Open();
            //Response.Write("Connection open"); 

            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "INSERT INTO admission (name,user_name,password,address,age) VALUES ('"+TxtName.Text+"','"+TxtUserName.Text+"','"+TxtPassword.Text+"','"+TxtAddress.Text+"','"+TxtAge.Text+"')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Response.Write("<h1>Record Saved</h1>");
        }
         catch (Exception Ex)
         {
             Response.Write("Connection error" + Ex.Message);
         }


    }
}