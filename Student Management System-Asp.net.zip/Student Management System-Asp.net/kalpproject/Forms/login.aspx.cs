﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
public partial class login : System.Web.UI.Page
{
    MySqlConnection con = new MySqlConnection(@"Data source=localhost;port=3306;initial catalog=mysms;user Id=root;password='';");
    protected void Page_Load(object sender, EventArgs e)
    { 
       
    }
    protected void Btnlogin_Click(object sender, EventArgs e)
    {
         
        con.Open();
        MySqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from login where username ='"+Txb1.Text+"' and  password='"+Txb2.Text+"'";
        cmd.ExecuteNonQuery();
        DataTable dt =  new DataTable();
        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
        da.Fill(dt);
        foreach(DataRow  dr in dt.Rows)
        { 
            Session["username"]=dr["username"].ToString();
          Response.Redirect("admin.aspx");
        }


        con.Close();
        Label1.Text = "invalid user name or password";

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        MySqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from login where username ='" + Txb1.Text + "' and  password='" + Txb2.Text + "'";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
        da.Fill(dt);
        foreach (DataRow dr in dt.Rows)
        {
            Session["username"] = dr["username"].ToString();
            Response.Redirect("general.aspx");
        }


        con.Close();
        Label1.Text = "invalid user name or password";

    }
}