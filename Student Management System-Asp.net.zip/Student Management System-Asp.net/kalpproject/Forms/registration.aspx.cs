﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;  

public partial class registration : System.Web.UI.Page
{
    MySqlConnection con = new MySqlConnection(@"Data source=localhost;port=3306;initial catalog=mysms;user Id=root;password='';");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = "server = localhost;DATABASE=mysms;UID=root;password=;=";
            con.Open();
            Response.Write("connection open");

           
            con.ConnectionString = "INSERT INTO registration (first name,last name,enter email,enter password)VALUES('"+Txfnm.Text+"','"+Txlnm.Text+"','"+Txem+"','"+Txpw+"')";

        }
        catch (Exception ex)
         {
           Response.Write("connection error"+ex.Message);
         } 

        
      
        

    }
}