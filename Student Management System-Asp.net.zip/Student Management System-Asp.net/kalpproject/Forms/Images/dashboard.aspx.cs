﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
public partial class Forms_Images_dashboard : System.Web.UI.Page
{

    public void fillGrid()
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = "SERVER=localhost;DATABASE=studentmanagementdb;UID=root;password=;";
        con.Open();
        MySqlDataAdapter Da = new MySqlDataAdapter("select id,firstname,lastname,email,phonno,location,address from staff_details", con);
        DataSet Ds = new DataSet();
        Da.Fill(Ds);
        GridView1.DataSource = Ds.Tables[0];
        GridView1.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        fillGrid();
    }
   
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
       
    }
}