﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class student_details : System.Web.UI.Page
{
    MySqlConnection con = new MySqlConnection(@"Data source=localhost;port=3306;initial catalog=studentmanagementdb; user Id=root; password=;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        Response.Write("connection open");
        MySqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO add_student(fname,lname,fathername,standard,	dob,email,pincode,mobile,location,address)values('" + TextBox1.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox10.Text + "','" + TextBox6.Text + "')";
        cmd.ExecuteNonQuery();
    }
}