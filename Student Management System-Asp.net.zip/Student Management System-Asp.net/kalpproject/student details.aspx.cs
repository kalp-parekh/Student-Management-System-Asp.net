﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

public partial class student_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = "SERVER=localhost;DATABASE=studentmanagementdb;UID=root;password=;";
            con.Open();
            //Response.Write("Connection open");

            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "INSERT INTO student_details (fname,lname,fathername,dob,email,phonenumber,password) VALUES ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Response.Write("<h1>Record Saved</h1>");
        }
        catch (Exception Ex)
        {
            Response.Write("Connection error" + Ex.Message);
        }
    }
}